package kr.or.ddit.chat.vo;

import java.util.Date;

import lombok.Data;
@Data
public class ChatVO  {

	private int chatNo;
	private String studyCode;  
	private String stuId;
	private String chatCont;
	private String chatDate;
	private String stuNameKo;
	
}
